﻿namespace BoatRacingSimulator.Enumerations
{
    public enum Positions
    {
        First,
        Second,
        Third
    }
}
