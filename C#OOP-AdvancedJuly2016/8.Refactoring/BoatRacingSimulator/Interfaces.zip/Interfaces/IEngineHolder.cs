﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IEngineHolder : IBoat
    {
    }
}
